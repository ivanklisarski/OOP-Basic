package Encapsulation.PizzaCalories;

public final class PizzaConstants {
    public static final double BASE_CALORIES = 2;

    private PizzaConstants() {}


}
