package DefiningClasses.DefineClassPerson;


public class Person {
    private String name;
    private int age;

    public Person() {
    }


}
