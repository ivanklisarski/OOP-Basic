package InterfacesAndAbstraction.MilitaryElite.contracts;

public interface SpecialisedSoldier extends Private{
}
