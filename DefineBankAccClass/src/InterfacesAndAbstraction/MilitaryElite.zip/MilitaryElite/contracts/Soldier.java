package InterfacesAndAbstraction.MilitaryElite.contracts;

public interface Soldier {
    String getId();

}
