package InterfacesAndAbstraction.MilitaryElite.contracts;

public interface Engineer extends SpecialisedSoldier{
}
