package InterfacesAndAbstraction.MilitaryElite.contracts;

public interface Repair {
}
