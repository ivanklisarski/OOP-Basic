package InterfacesAndAbstraction.MilitaryElite.contracts;

public interface Spy extends Soldier{
}
