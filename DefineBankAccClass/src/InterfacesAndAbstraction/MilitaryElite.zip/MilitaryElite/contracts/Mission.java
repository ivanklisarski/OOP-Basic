package InterfacesAndAbstraction.MilitaryElite.contracts;

public interface Mission {
    void completeMission();
}
