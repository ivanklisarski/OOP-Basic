package InterfacesAndAbstraction.MilitaryElite.contracts;

public interface Commando extends SpecialisedSoldier{
}
