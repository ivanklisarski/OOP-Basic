package InterfacesAndAbstraction.MilitaryElite.contracts;

public interface LeutenantGeneral extends Private{
}
