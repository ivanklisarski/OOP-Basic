package InterfacesAndAbstraction.MilitaryElite.contracts;

public interface Private extends Soldier{
}
