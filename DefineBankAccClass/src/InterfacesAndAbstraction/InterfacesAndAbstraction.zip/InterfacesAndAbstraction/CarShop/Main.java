package InterfacesAndAbstraction.CarShop;

public class Main {
    public static void main(String[] args) {
        Car seat = new Seat("Spain", "Leon", 110, "gray");


        System.out.println(seat.toString());
    }

}
