package InterfacesAndAbstraction.BorderControl;

public interface Identifable {
    String getId();
}
