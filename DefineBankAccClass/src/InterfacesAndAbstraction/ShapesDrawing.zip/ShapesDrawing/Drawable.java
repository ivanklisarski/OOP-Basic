package InterfacesAndAbstraction.ShapesDrawing;

public interface Drawable {
    void draw();
}
