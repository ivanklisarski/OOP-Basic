package InterfacesAndAbstraction.Ferrari;

public interface Car {
    String useBrakes();
    String pushTheGas();

}
