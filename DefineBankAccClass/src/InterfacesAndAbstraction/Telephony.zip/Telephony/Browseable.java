package InterfacesAndAbstraction.Telephony;

public interface Browseable {
    String browseTheWorldWideWeb(String url);
}
