package InterfacesAndAbstraction.Telephony;

public interface Callable {
    String callOtherPhones(String phoneNumber);
}
