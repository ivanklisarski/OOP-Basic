package InterfacesAndAbstraction.Mood3.contracts;

public interface Archangel {
    int getSpecialPoints();

}
