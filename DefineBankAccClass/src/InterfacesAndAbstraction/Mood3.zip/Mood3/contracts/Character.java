package InterfacesAndAbstraction.Mood3.contracts;

public interface Character {
    String getUsername();

    String getHashedPassword();

    int getLevel();

}
