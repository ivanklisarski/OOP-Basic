package InterfacesAndAbstraction.Mood3.contracts;

public interface Demon {
    double getSpecialPoints();

}
