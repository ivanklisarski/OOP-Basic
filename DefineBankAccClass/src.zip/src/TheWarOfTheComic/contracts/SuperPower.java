package TheWarOfTheComic.contracts;

public interface SuperPower {
    String getName();
	 double getPowerPoints();

}
