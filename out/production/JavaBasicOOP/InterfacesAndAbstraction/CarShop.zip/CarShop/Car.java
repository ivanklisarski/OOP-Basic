package InterfacesAndAbstraction.CarShop;

public interface Car {
    int tires = 4;

    String getModel();
    String getColor();
    Integer getHorsePower();
}
