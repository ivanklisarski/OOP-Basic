package InterfacesAndAbstraction.CarShop;

public class Main {
    public static void main(String[] args) {
        Car seat = new Seat("Spain", "Leon", "gray", 110);


        System.out.println(seat.toString());
    }

}
