package InterfacesAndAbstraction.Person;

public interface Birthable {
    String Birthable();
}
