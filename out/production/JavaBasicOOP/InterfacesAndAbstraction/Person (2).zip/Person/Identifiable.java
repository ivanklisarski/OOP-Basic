package InterfacesAndAbstraction.Person;

public interface Identifiable {
    String id();
}
