package InterfacesAndAbstraction.BirthdayCelebrations;

public interface Identifable {
    String getId();
}
