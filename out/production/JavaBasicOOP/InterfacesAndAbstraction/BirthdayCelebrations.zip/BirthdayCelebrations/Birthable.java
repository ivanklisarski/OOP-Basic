package InterfacesAndAbstraction.BirthdayCelebrations;

public interface Birthable {
   String getBirthdate();
}
