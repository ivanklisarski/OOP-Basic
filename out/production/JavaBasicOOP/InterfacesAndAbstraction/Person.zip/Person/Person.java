package InterfacesAndAbstraction.Person;

public interface Person {
    String name();
    int age();
}
