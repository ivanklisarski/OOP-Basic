package InterfacesAndAbstraction.CollectionHierarchy.contracts;

public interface AddCollection {
    int add(String str);


}
