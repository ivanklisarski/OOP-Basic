package InterfacesAndAbstraction.CollectionHierarchy.contracts;

public interface MyList extends AddRemoveCollection{
    int used();

}
