package InterfacesAndAbstraction.CollectionHierarchy.contracts;

public interface AddRemoveCollection extends AddCollection{
    String remove();

}
