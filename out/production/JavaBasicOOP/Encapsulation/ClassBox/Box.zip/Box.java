package Encapsulation.ClassBox;

public class Box {
    private double length;
    private double width;
    private double height;

    public Box(double length, double width, double height) {
        this.length = length;
        this.width = width;
        this.height = height;
    }

     double surfaceArea(double length,double height,double width){
          return 2*(length*width) + 2*(length*height) + 2*(width*height);
    }

     double LatheralSurfaceArea(){
        return 2d*this.length*height+ 2d*this.width*this.height;


    }

    public double Volume(double length,double height,double width){
        return length*width*height;
    }


}
