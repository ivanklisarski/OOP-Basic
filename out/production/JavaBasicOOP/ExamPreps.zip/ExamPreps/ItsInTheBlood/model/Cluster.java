package ExamPreps.ItsInTheBlood.model;

import ExamPreps.ItsInTheBlood.model.cells.Cell;

import java.util.ArrayList;
import java.util.List;

public class Cluster {
    private String id;
    private int rows;
    private int cows;
    private List<Cell> cells;

    public Cluster(String id, int rows, int cows) {
        this.id = id;
        this.rows = rows;
        this.cows = cows;
        this.cells = new ArrayList<>();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("----Cluster ").append(this.id).append(System.lineSeparator());
      //  this.cells.sort(Comparator.naturalOrder());
      //  for (Cell cell : this.cells) {
      //      sb.append(cell).append(System.lineSeparator());
      //  }
        return sb.toString().trim();
    }
    public boolean addCell(Cell cell) {
        if (cell.getPositionRow() > this.cows || cell.getPositionCol() > this.rows) {
            return false;
        }
        this.cells.add(cell);
        return true;
    }

    public String getId() {
        return id;
    }

    public int getCellsCount() {
        return this.cells.size();
    }

}
