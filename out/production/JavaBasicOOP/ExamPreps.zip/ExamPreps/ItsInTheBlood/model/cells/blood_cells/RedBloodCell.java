package ExamPreps.ItsInTheBlood.model.cells.blood_cells;

import ExamPreps.ItsInTheBlood.model.cells.BloodCell;

public class RedBloodCell extends BloodCell {
    private int velocity;
    public RedBloodCell(String id, int health, int positionRow, int positionCol, int velocity) {
        super(id, health, positionRow, positionCol);
        this.velocity = velocity;
    }
    @Override
    public String toString() {
        return String.format("%s%n--------Health: %d | Velocity: %d | Energy: %d",
                super.toString(), super.getHealth(), this.velocity, this.getEnergy());
    }

    @Override
    protected int getEnergy() {
        return super.getHealth() + this.velocity;
    }
}
