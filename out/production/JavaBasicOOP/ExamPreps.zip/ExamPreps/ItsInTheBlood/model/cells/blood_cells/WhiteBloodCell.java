package ExamPreps.ItsInTheBlood.model.cells.blood_cells;

import ExamPreps.ItsInTheBlood.model.cells.BloodCell;

public class WhiteBloodCell extends BloodCell{

    private int size;
    public WhiteBloodCell(String id, int health, int positionRow, int positionCol,int size) {
        super(id, health, positionRow, positionCol);
        this.size = size;
    }
    @Override
    public String toString() {
        return String.format("%s%n--------Health: %d | Size: %d | Energy: %d",
                super.toString(), super.getHealth(), this.size, this.getEnergy());
    }

    @Override
    protected int getEnergy() {
        return 0;
    }
}
