package TheExpanse.factories;

import TheExpanse.ColonistsConstants;
import TheExpanse.model.colonists.Colonist;
import TheExpanse.model.colonists.Soldier;
import TheExpanse.model.engineer.HardwareEngineer;
import TheExpanse.model.engineer.SoftwareEngineer;
import TheExpanse.model.medic.GeneralPractitioner;
import TheExpanse.model.medic.Surgeon;

public final class ColonistsFactory {

    private static final ColonistsFactory INSTANCE = new ColonistsFactory();

    private ColonistsFactory() {
    }

    public static ColonistsFactory getInstance() {
        return INSTANCE;
    }

    public Colonist createColonist(String... parameters) {
        String type = parameters[0];
        String colonistId = parameters[1];
        String familyId = parameters[2];
        int talent = Integer.parseInt(parameters[3]);
        int age = Integer.parseInt(parameters[4]);
        String sign = (parameters.length == 6) ? parameters[5] : null;

        switch (type) {
            case ColonistsConstants.SOLDIER:
                return new Soldier(colonistId, familyId, talent, age);
            case ColonistsConstants.HARDWARE_ENGINEER:
                return new HardwareEngineer(colonistId, familyId, talent, age);
            case ColonistsConstants.SOFTWARE_ENGINEER:
                return new SoftwareEngineer(colonistId, familyId, talent, age);
            case ColonistsConstants.SURGEON:
                return new Surgeon(colonistId, familyId, talent, age, sign);
            case ColonistsConstants.GENERAL_PRACTITIONER:
                return new GeneralPractitioner(colonistId, familyId, talent, age, sign);
            default:
                return null;
        }
    }
}
